function checkStringsAnagram(a:string, b:string) {
   let len1 = a.length;
   let len2 = b.length;
   if(len1 !== len2){
      console.log('Invalid Input');
      return
   }
   let str1 = a.split('').sort().join('');
   let str2 = b.split('').sort().join('');
   if(str1 === str2){
      console.log("True");
   } else { 
      console.log("False");
   }
}

let arg1:string = prompt("Enter first word: \n")!
let arg2:string = prompt("Enter second word: \n")!
checkStringsAnagram(arg1, arg2)