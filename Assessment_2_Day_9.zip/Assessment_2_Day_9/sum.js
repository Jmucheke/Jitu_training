function sum(){
 let user_input = prompt("Enter values separated by commas").split(",")
 alert(user_input)


}